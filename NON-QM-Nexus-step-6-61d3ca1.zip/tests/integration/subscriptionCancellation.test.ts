// Integration tests for self-serve subscription cancellation against the
// REAL Supabase project. Same skip-without-credentials convention as the
// other tests/integration/*.test.ts files.
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { randomUUID } from "node:crypto";
import { createClient as createSupabaseClient, type SupabaseClient } from "@supabase/supabase-js";
import { getEffectivePlan } from "@/lib/repository/membership";
import { SupabaseRepository } from "@/lib/repository/supabaseRepository";
import { PLATFORM_CATALOG_ORGANIZATION_ID } from "@/lib/platformCatalog";

try {
  (process as unknown as { loadEnvFile?: (path?: string) => void }).loadEnvFile?.(".env.local");
} catch {
  // ignore — CI has no .env.local
}

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const hasCredentials = Boolean(SUPABASE_URL && ANON_KEY && SERVICE_ROLE_KEY);

describe.skipIf(!hasCredentials)("Subscription cancellation (live database)", () => {
  let admin: SupabaseClient;
  let userClient: SupabaseClient;
  let userId: string;
  let organizationId: string;
  let essentialPlanId: string;
  const testEmail = `nqn-cancel-integration-${Date.now()}@gmail.com`;
  const testPassword = "Cancel-Integration-Pw-123";
  const testLenderName = `Cancel-test Lender ${Date.now()}`;
  const testLenderId = randomUUID();
  let testProgramId: string;

  beforeAll(async () => {
    admin = createSupabaseClient(SUPABASE_URL!, SERVICE_ROLE_KEY!, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: essential } = await admin.from("membership_plans").select("id").eq("key", "essential").single();
    essentialPlanId = essential!.id;

    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email: testEmail,
      password: testPassword,
      email_confirm: true,
    });
    if (createError || !created.user) throw new Error(`Failed to create test user: ${createError?.message}`);
    userId = created.user.id;

    userClient = createSupabaseClient(SUPABASE_URL!, ANON_KEY!, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    await userClient.auth.signInWithPassword({ email: testEmail, password: testPassword });

    const { data: membership } = await userClient
      .from("memberships")
      .select("organization_id")
      .eq("user_id", userId)
      .maybeSingle();
    organizationId = membership!.organization_id as string;

    await admin.from("lenders").insert({ organization_id: PLATFORM_CATALOG_ORGANIZATION_ID, name: testLenderName, tier_level: 1, id: testLenderId });
    // External-audit fix (2026-07-28) made listLenders verified-only —
    // this disposable test fixture needs a program + human_verified
    // guideline_version to exercise cancellation/reactivation tier
    // access (not verification, which isn't what this suite tests).
    const { data: testProgram, error: testProgramError } = await admin
      .from("programs")
      .insert({
        organization_id: PLATFORM_CATALOG_ORGANIZATION_ID,
        lender_id: testLenderId,
        name: `${testLenderName} — Test Program`,
        is_sample_data: false,
        active: true,
        config: { minFico: 660, baseMaxLtv: 80, incomeDocTypes: ["full_doc"] },
      })
      .select("id")
      .single();
    if (testProgramError || !testProgram) throw new Error(`Failed to insert test program: ${testProgramError?.message}`);
    testProgramId = testProgram.id as string;
    const { error: gvError } = await admin.from("guideline_versions").insert({
      organization_id: PLATFORM_CATALOG_ORGANIZATION_ID,
      program_id: testProgramId,
      label: "Test fixture — verified",
      effective_date: new Date().toISOString().slice(0, 10),
      verification_status: "human_verified",
    });
    if (gvError) throw new Error(`Failed to insert test guideline_version: ${gvError.message}`);

    // Assign the Essential plan directly (mirrors what an admin does).
    await admin
      .from("user_subscriptions")
      .upsert({ user_id: userId, plan_id: essentialPlanId, assigned_by: userId }, { onConflict: "user_id" });
  }, 30_000);

  afterAll(async () => {
    if (testProgramId) {
      await admin.from("guideline_versions").delete().eq("program_id", testProgramId);
      await admin.from("programs").delete().eq("id", testProgramId);
    }
    await admin.from("lenders").delete().eq("organization_id", PLATFORM_CATALOG_ORGANIZATION_ID).eq("name", testLenderName);
    if (organizationId) {
      await admin.from("memberships").delete().eq("organization_id", organizationId);
      await admin.from("organizations").delete().eq("id", organizationId);
    }
    if (userId) {
      await admin.from("user_subscriptions").delete().eq("user_id", userId);
      await admin.from("users").delete().eq("id", userId);
      await admin.auth.admin.deleteUser(userId);
    }
  }, 30_000);

  it("an active subscription grants tier access before cancellation", async () => {
    const plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(1);
    expect(plan.canceledAt).toBeNull();

    const repo = new SupabaseRepository(userClient, userId);
    const lenders = await repo.listLenders(organizationId);
    expect(lenders.map((l) => l.name)).toContain(testLenderName);
  }, 15_000);

  it("self-serve cancel_own_subscription() revokes access but keeps plan history", async () => {
    const { error } = await userClient.rpc("cancel_own_subscription");
    expect(error).toBeNull();

    const plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(0); // access revoked
    expect(plan.planName).toBe("Essential"); // history kept
    expect(plan.canceledAt).not.toBeNull();

    const repo = new SupabaseRepository(userClient, userId);
    const lenders = await repo.listLenders(organizationId);
    expect(lenders).toHaveLength(0);
  }, 15_000);

  it("a canceled user cannot use the RPC to cancel someone else's subscription", async () => {
    // The RPC only ever touches auth.uid()'s own row — call it again as the
    // same already-canceled user and confirm nothing else was touched /
    // no error escalation happened.
    const { error } = await userClient.rpc("cancel_own_subscription");
    expect(error).toBeNull();
    const plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(0);
  }, 15_000);

  it("admin reactivation (clearing canceled_at) restores tier access", async () => {
    await admin.from("user_subscriptions").update({ canceled_at: null }).eq("user_id", userId);

    const plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(1);
    expect(plan.canceledAt).toBeNull();

    const repo = new SupabaseRepository(userClient, userId);
    const lenders = await repo.listLenders(organizationId);
    expect(lenders.map((l) => l.name)).toContain(testLenderName);
  }, 15_000);

  it("self-serve reactivate_own_subscription() restores tier access after a self-serve cancel", async () => {
    const { error: cancelErr } = await userClient.rpc("cancel_own_subscription");
    expect(cancelErr).toBeNull();
    let plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(0);

    const { error: reactivateErr } = await userClient.rpc("reactivate_own_subscription");
    expect(reactivateErr).toBeNull();

    plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(1);
    expect(plan.planName).toBe("Essential");
    expect(plan.canceledAt).toBeNull();

    const repo = new SupabaseRepository(userClient, userId);
    const lenders = await repo.listLenders(organizationId);
    expect(lenders.map((l) => l.name)).toContain(testLenderName);
  }, 15_000);

  it("reactivate_own_subscription() on an already-active subscription is a safe no-op", async () => {
    const { error } = await userClient.rpc("reactivate_own_subscription");
    expect(error).toBeNull();
    const plan = await getEffectivePlan(userClient, userId);
    expect(plan.tierLevel).toBe(1);
    expect(plan.canceledAt).toBeNull();
  }, 15_000);
});
